package com.restful.brewery.beerAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
