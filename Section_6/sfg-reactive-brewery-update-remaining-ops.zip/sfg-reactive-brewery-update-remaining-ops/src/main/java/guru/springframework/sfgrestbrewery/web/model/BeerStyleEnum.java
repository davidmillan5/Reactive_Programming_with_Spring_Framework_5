package guru.springframework.sfgrestbrewery.web.model;


public enum BeerStyleEnum {

    LAGER, PILSNER, STOUT, GOSE, PORTER, ALE, WHEAT, IPA, PALE_ALE, SAISON
}
